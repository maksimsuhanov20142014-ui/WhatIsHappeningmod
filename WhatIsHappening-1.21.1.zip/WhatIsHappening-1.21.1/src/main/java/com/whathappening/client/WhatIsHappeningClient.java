package com.whathappening.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class WhatIsHappeningClient implements ClientModInitializer {
    public static final String MOD_ID = "whathappening";
    public static final Identifier WHAT_IS_HAPPENING_ID = Identifier.of(MOD_ID, "what_is_happening");
    public static final SoundEvent WHAT_IS_HAPPENING = SoundEvent.of(WHAT_IS_HAPPENING_ID);

    @Override
    public void onInitializeClient() {
        Registry.register(Registries.SOUND_EVENT, WHAT_IS_HAPPENING_ID, WHAT_IS_HAPPENING);
    }
}
