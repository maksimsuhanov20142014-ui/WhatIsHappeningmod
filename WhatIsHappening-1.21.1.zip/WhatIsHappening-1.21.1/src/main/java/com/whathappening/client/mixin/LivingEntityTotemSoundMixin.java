package com.whathappening.client.mixin;

import com.whathappening.client.WhatIsHappeningClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LivingEntity.class)
public abstract class LivingEntityTotemSoundMixin {
    @Redirect(
        method = "tryUseTotem",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/entity/LivingEntity;playSound(Lnet/minecraft/sound/SoundEvent;FF)V"
        )
    )
    private void whathappening$replaceTotemSound(LivingEntity entity, SoundEvent sound, float volume, float pitch) {
        entity.playSound(WhatIsHappeningClient.WHAT_IS_HAPPENING, 1.5F, 1.0F);
    }
}
